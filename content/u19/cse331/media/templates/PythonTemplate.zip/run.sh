#!/bin/bash

python HW1.py $1 $2