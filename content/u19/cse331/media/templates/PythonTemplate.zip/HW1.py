import sys


def main():
    input_filename = sys.argv[1]
    output_filename = sys.argv[2]


if __name__ == "__main__":
    main()
