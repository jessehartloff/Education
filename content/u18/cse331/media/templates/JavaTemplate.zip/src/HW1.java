
public class HW1{

    public static void main(String[] args){
        String inputFilename = args[0];
        String outputFilename = args[1];

        // TODO


    }

}
