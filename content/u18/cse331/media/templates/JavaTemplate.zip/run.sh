#!/bin/bash

java -cp src/ HW1 $1 $2