#include <iostream>

using namespace std;

int main(int argc, char *argv[]){
    string inputFilename = argv[1];
    string outputFilename = argv[2];


    return 0;
}